package com.ikiuly.music

import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF090B0A)
private val SurfaceDark = Color(0xFF171B18)
private val Green = Color(0xFF1ED760)
private val Muted = Color(0xFF9AA39C)

data class Track(val uri: String, val title: String, val artist: String = "File musik lokal")

data class LyricLine(val timeMs: Long, val text: String)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    private val audioPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val current = mediaController
        if (uris.isNotEmpty() && current != null) {
            val newItems = uris.map { uri ->
                runCatching { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                val name = queryDisplayName(uri) ?: "Musik"
                Track(uri.toString(), name.substringBeforeLast('.', name))
            }
            val items = newItems.map { MediaItem.fromUri(Uri.parse(it.uri)) }
            current.addMediaItems(items)
            if (current.mediaItemCount > 0 && current.playbackState == Player.STATE_IDLE) current.prepare()
        }
    }

    private val lyricPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val text = runCatching { contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
            if (text != null) {
                getSharedPreferences("ikiuly", MODE_PRIVATE).edit().putString("lyrics", text).apply()
                lyricsText.value = text
            }
        }
    }

    private val lyricsText = mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lyricsText.value = getSharedPreferences("ikiuly", MODE_PRIVATE).getString("lyrics", "") ?: ""
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            runCatching { mediaController = controllerFuture?.get() }
        }, { command -> command.run() })

        setContent {
            val controller = mediaController
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = SurfaceDark, primary = Green,
                onBackground = Color.White, onSurface = Color.White
            )) {
                IkiiUlyApp(
                    controller = controller,
                    lyrics = lyricsText.value,
                    onAddMusic = { audioPicker.launch(arrayOf("audio/*")) },
                    onAddLyrics = { lyricPicker.launch(arrayOf("text/*", "application/octet-stream")) }
                )
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@Composable
private fun IkiiUlyApp(
    controller: MediaController?,
    lyrics: String,
    onAddMusic: () -> Unit,
    onAddLyrics: () -> Unit
) {
    var tab by remember { mutableStateOf("Beranda") }
    var search by remember { mutableStateOf("") }
    var favoriteUris by remember { mutableStateOf(setOf<String>()) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentTitle by remember { mutableStateOf("Pilih musik") }
    var currentUri by remember { mutableStateOf("") }

    LaunchedEffect(controller) {
        if (controller == null) return@LaunchedEffect
        fun update() {
            currentPosition = controller.currentPosition.coerceAtLeast(0L)
            duration = controller.duration.takeIf { it > 0 } ?: 0L
            isPlaying = controller.isPlaying
            currentTitle = controller.currentMediaItem?.mediaMetadata?.title?.toString()
                ?: controller.currentMediaItem?.localConfiguration?.uri?.lastPathSegment ?: "Pilih musik"
            currentUri = controller.currentMediaItem?.localConfiguration?.uri?.toString() ?: ""
        }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { update() }
            override fun onPlaybackStateChanged(playbackState: Int) { update() }
        }
        controller.addListener(listener)
        while (true) {
            update()
            kotlinx.coroutines.delay(400)
        }
    }

    val trackCount = controller?.mediaItemCount ?: 0
    val lyricLines = remember(lyrics) { parseLrc(lyrics) }
    val activeLyric = lyricLines.indexOfLast { it.timeMs <= currentPosition }.coerceAtLeast(0)

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            Column {
                if (trackCount > 0) {
                    MiniPlayer(currentTitle, isPlaying, currentPosition, duration,
                        onPlay = { if (isPlaying) controller?.pause() else controller?.play() },
                        onOpen = { tab = "Diputar" })
                }
                NavigationBar(containerColor = Color(0xFF101411), contentColor = Color.White) {
                    listOf(
                        Triple("Beranda", Icons.Default.Home, "Beranda"),
                        Triple("Cari", Icons.Default.Search, "Cari"),
                        Triple("Koleksi", Icons.Default.LibraryMusic, "Koleksi")
                    ).forEach { (label, icon, key) ->
                        NavigationBarItem(
                            selected = tab == key, onClick = { tab = key },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green, selectedTextColor = Green,
                                indicatorColor = Color(0xFF233329), unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                "Beranda" -> HomeScreen(trackCount, onAddMusic, onAddLyrics, currentTitle) {
                    tab = "Diputar"
                }
                "Cari" -> SearchScreen(search, { search = it }, onAddMusic)
                "Koleksi" -> LibraryScreen(trackCount, onAddMusic, favoriteUris)
                else -> PlayerScreen(
                    controller, currentTitle, currentPosition, duration, isPlaying,
                    lyrics, activeLyric, onAddLyrics,
                    onToggleFavorite = {
                        favoriteUris = if (currentUri in favoriteUris) favoriteUris - currentUri else favoriteUris + currentUri
                    },
                    isFavorite = currentUri in favoriteUris
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(count: Int, onAddMusic: () -> Unit, onAddLyrics: () -> Unit, title: String, onPlayer: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 20.dp)) {
        item {
            Text("IkiiUly", color = Green, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("Music", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(22.dp))
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF244A32), Color(0xFF14231A))))
                .clickable { onAddMusic() }.padding(22.dp)) {
                Column {
                    Text("DENGARKAN MUSIK FAVORITMU", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Musikmu.\nGayamu.", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = onAddMusic, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)) {
                        Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Tambah musik")
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("Perpustakaan musik", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("$count lagu ditambahkan", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickTile("Lagu lokal", Icons.Default.LibraryMusic, Modifier.weight(1f), onAddMusic)
                QuickTile("Tambah lirik", Icons.Default.Lyrics, Modifier.weight(1f), onAddLyrics)
            }
            Spacer(Modifier.height(22.dp))
            Text("Terakhir diputar", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SurfaceDark)
                .clickable { onPlayer() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                AlbumArt(54)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text("Buka pemutar", color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Green)
            }
            Spacer(Modifier.height(18.dp))
            Text("Catatan", color = Green, fontWeight = FontWeight.Bold)
            Text("IkiiUly Music memutar file musik yang kamu pilih dari perangkat. Tambahkan file .LRC untuk lirik yang tersinkronisasi.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
private fun QuickTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(SurfaceDark).clickable { onClick() }.padding(16.dp)) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(25.dp))
        Spacer(Modifier.height(14.dp))
        Text(title, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SearchScreen(query: String, onQuery: (String) -> Unit, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Cari", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Cari lagu atau artis") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true,
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Green, unfocusedBorderColor = Color(0xFF414941),
                focusedTextColor = Color.White, unfocusedTextColor = Color.White
            )
        )
        Spacer(Modifier.height(18.dp))
        Text("Musik di perangkat", fontWeight = FontWeight.Bold, fontSize = 19.sp)
        Text("Pilih file audio dari penyimpanan HP untuk mulai membangun koleksimu.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)) {
            Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Pilih file musik")
        }
    }
}

@Composable
private fun LibraryScreen(count: Int, onAdd: () -> Unit, favorites: Set<String>) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Koleksi kamu", fontSize = 29.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceDark).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Favorite, null, tint = Green, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Lagu favorit", fontWeight = FontWeight.Bold)
                Text("${favorites.size} lagu", color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceDark).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.LibraryMusic, null, tint = Green, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Musik lokal", fontWeight = FontWeight.Bold)
                Text("$count lagu dalam antrean pemutar", color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(20.dp))
        Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)) {
            Text("Tambah lagu")
        }
    }
}

@Composable
private fun PlayerScreen(
    controller: MediaController?, title: String, position: Long, duration: Long, playing: Boolean,
    lyrics: String, activeLyric: Int, onAddLyrics: () -> Unit,
    onToggleFavorite: () -> Unit, isFavorite: Boolean
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(16.dp))
        Text("SEDANG DIPUTAR", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(24.dp))
        AlbumArt(250)
        Spacer(Modifier.height(25.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Musik lokal", color = Muted, fontSize = 13.sp)
            }
            IconButton(onClick = onToggleFavorite) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Green)
            }
        }
        Slider(
            value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
            onValueChange = { controller?.seekTo(it.toLong()) },
            valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()),
            colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green, inactiveTrackColor = Color(0xFF414941))
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), color = Muted, fontSize = 11.sp)
            Text(formatTime(duration), color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            IconButton(onClick = { controller?.shuffleModeEnabled = !(controller?.shuffleModeEnabled ?: false) }) {
                Icon(Icons.Default.Shuffle, null, tint = Muted)
            }
            IconButton(onClick = { controller?.seekToPreviousMediaItem() }, modifier = Modifier.size(54.dp)) {
                Icon(Icons.Default.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(34.dp))
            }
            FilledIconButton(
                onClick = { if (playing) controller?.pause() else controller?.play() },
                modifier = Modifier.size(66.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Green, contentColor = Color.Black)
            ) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, modifier = Modifier.size(38.dp))
            }
            IconButton(onClick = { controller?.seekToNextMediaItem() }, modifier = Modifier.size(54.dp)) {
                Icon(Icons.Default.SkipNext, null, tint = Color.White, modifier = Modifier.size(34.dp))
            }
            IconButton(onClick = {
                controller?.repeatMode = when (controller?.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }) { Icon(Icons.Default.Repeat, null, tint = Muted) }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Lirik lagu", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onAddLyrics) { Text("Impor .LRC", color = Green) }
        }
        if (lyrics.isBlank()) {
            Text("Belum ada lirik. Impor file .LRC untuk sinkronisasi.", color = Muted, fontSize = 12.sp)
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(16.dp)).background(SurfaceDark),
                contentPadding = PaddingValues(vertical = 14.dp, horizontal = 12.dp)
            ) {
                items(lyricLinesForUi(lyrics)) { line ->
                    val index = lyricLinesForUi(lyrics).indexOf(line)
                    Text(
                        line.text,
                        color = if (index == activeLyric) Green else Muted,
                        fontSize = if (index == activeLyric) 17.sp else 14.sp,
                        fontWeight = if (index == activeLyric) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun MiniPlayer(title: String, playing: Boolean, position: Long, duration: Long, onPlay: () -> Unit, onOpen: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF202820)).clickable { onOpen() }) {
        Row(Modifier.padding(start = 12.dp, end = 8.dp, top = 8.dp, bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(42)
            Spacer(Modifier.width(10.dp))
            Text(title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            IconButton(onClick = onPlay) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Green)
            }
        }
        LinearProgressIndicator(
            progress = { if (duration > 0) position.toFloat().div(duration).coerceIn(0f, 1f) else 0f },
            modifier = Modifier.fillMaxWidth().height(2.dp),
            color = Green, trackColor = Color.Transparent
        )
    }
}

@Composable
private fun AlbumArt(size: Int) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1ED760), Color(0xFF173D29), Color(0xFF101510)))),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size((size * .48f).dp))
    }
}

private fun formatTime(ms: Long): String {
    if (ms < 0) return "0:00"
    return String.format("%d:%02d", TimeUnit.MILLISECONDS.toMinutes(ms), TimeUnit.MILLISECONDS.toSeconds(ms) % 60)
}

private fun parseLrc(raw: String): List<LyricLine> {
    val regex = Regex("""\[(\d{2}):(\d{2})(?:[.:](\d{1,3}))?](.*)""")
    return raw.lineSequence().mapNotNull { line ->
        val match = regex.find(line.trim()) ?: return@mapNotNull null
        val min = match.groupValues[1].toLongOrNull() ?: 0L
        val sec = match.groupValues[2].toLongOrNull() ?: 0L
        val fractionRaw = match.groupValues[3]
        val fraction = when (fractionRaw.length) {
            1 -> (fractionRaw.toLongOrNull() ?: 0L) * 100
            2 -> (fractionRaw.toLongOrNull() ?: 0L) * 10
            3 -> fractionRaw.toLongOrNull() ?: 0L
            else -> 0L
        }
        LyricLine((min * 60 + sec) * 1000 + fraction, match.groupValues[4].trim())
    }.sortedBy { it.timeMs }
}

private fun lyricLinesForUi(raw: String): List<LyricLine> = parseLrc(raw)
