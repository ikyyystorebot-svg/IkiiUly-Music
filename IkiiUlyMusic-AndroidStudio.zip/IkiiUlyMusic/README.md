# IkiiUly Music — Android Native (Kotlin + Jetpack Compose)

Aplikasi pemutar musik lokal Android dengan Media3 ExoPlayer, MediaSession untuk kontrol notifikasi/lock screen, mini player, playlist antrean, favorit sesi, dan lirik LRC tersinkronisasi.

## Kebutuhan
- Android Studio versi stabil yang mendukung Android Gradle Plugin 8.7.3
- JDK 17
- Android SDK 35
- Koneksi internet saat pertama kali Gradle mengunduh dependency

## Membuka project
1. Ekstrak `IkiiUlyMusic.zip`.
2. Buka Android Studio → **Open**.
3. Pilih folder `IkiiUlyMusic` (folder yang berisi `settings.gradle.kts`).
4. Tunggu **Gradle Sync** selesai.
5. Sambungkan HP Android dengan USB debugging aktif, atau buat emulator.
6. Tekan tombol **Run ▶**.

## Membuat APK
1. Android Studio → **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**.
2. Setelah selesai, pilih **locate** pada notifikasi build.
3. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
4. Untuk APK rilis: **Build → Generate Signed Bundle / APK… → APK**, lalu buat atau pilih keystore milikmu. Simpan keystore dan password dengan aman.

## Cara memakai
1. Buka IkiiUly Music.
2. Tekan **Tambah musik** dan pilih satu atau beberapa file audio dari perangkat.
3. Buka tab **Cari** atau **Koleksi** untuk menambahkan musik lain.
4. Ketuk mini player untuk membuka halaman pemutar.
5. Untuk lirik, siapkan file `.lrc` dengan timestamp, lalu tekan **Impor .LRC**.

Contoh isi file LRC:
```
[ti:Contoh Lagu]
[ar:Artis]
[00:05.00]Baris lirik pertama
[00:09.50]Baris lirik kedua
[00:14.00]Baris lirik ketiga
```
Lirik yang aktif mengikuti posisi pemutaran. Timestamp perlu disesuaikan dengan rekaman lagu yang digunakan.

## Catatan
- Versi ini memutar file audio yang dipilih pengguna dari perangkat. Tidak menyertakan katalog lagu komersial atau sumber unduhan tanpa izin.
- Durasi lagu diambil dari pemutar audio saat metadata tersedia.
- Lirik diimpor dari file LRC; sinkronisasi tergantung akurasi timestamp LRC.
- Favorit pada prototipe ini tersimpan selama sesi aplikasi; playlist permanen dan sinkronisasi cloud belum disertakan.
- Jika Gradle meminta versi SDK, instal Android SDK Platform 35 melalui SDK Manager.
